import{b as m,s as u}from"./index.fd9110ce.js";import"./themeHandler.68558200.js";let g=function(){return!!document.querySelector("#prompt-helper-btn")},v=m.exports.runtime.getURL("img/"),f=m.exports.runtime.getURL(""),h=`
<button id="prompt-helper-btn" tabindex="0" class="btn btn-small btn-filled btn-primary" type="button">
	<span class="btn-label-wrap">
		<span class="btn-label-inner">
    Prompt Helper</span> 
	</span>
</button>

<a id="gpt3-synonym" data-selection="" class="btn btn-small btn-filled btn-primary">Synonym with GPT-3

</a>
<a id="gpt3-autocomplete" class="btn btn-small btn-outlined ">Autocomplete with GPT-3</a>

<a href="${f}options.html" target="_blank" class="btn btn-small btn-icon btn-options">
<svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
  <path stroke-linecap="round" stroke-linejoin="round" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
</svg>

<span class="btn-spinner"
      ><div class="spinner">
        <svg
          stroke="currentColor"
          fill="currentColor"
          stroke-width="0"
          viewBox="0 0 1024 1024"
          class="spinner-spin"
          color="currentColor"
          height="1.2em"
          width="1.2em"
          xmlns="http://www.w3.org/2000/svg"
          style="color: currentcolor"
        >
          <path
            d="M988 548c-19.9 0-36-16.1-36-36 0-59.4-11.6-117-34.6-171.3a440.45 440.45 0 0 0-94.3-139.9 437.71 437.71 0 0 0-139.9-94.3C629 83.6 571.4 72 512 72c-19.9 0-36-16.1-36-36s16.1-36 36-36c69.1 0 136.2 13.5 199.3 40.3C772.3 66 827 103 874 150c47 47 83.9 101.8 109.7 162.7 26.7 63.1 40.2 130.2 40.2 199.3.1 19.9-16 36-35.9 36z"
          ></path>
        </svg></div
    ></span>
</a>
`,b=`
<label class="darkmode-toggle-wrapper">
  <input type="checkbox" id="darkmode-toggle" aria-label="dark mode toggle" class="darkmode-toggle-checkbox">
  <div class="darkmode-toggle-circle"></div>
  <span class="darkmode-toggle-emoji">
  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
  <path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z" />
</svg></span>
  <span class="darkmode-toggle-emoji"><svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
  <path fill-rule="evenodd" d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z" clip-rule="evenodd" />
</svg></span>
</label>
`,w=function(){let r="";if(!window.prompts)r="<div>Something went wrong, no prompts found!</div>";else{r=document.createDocumentFragment();let o=document.createElement("div");o.classList.add("helper-drawer"),o.id="prompt-helper-drawer",r.appendChild(o);for(let n in window.prompts){let e=window.prompts[n],a=`
				<h4 class="prompt-group-title" title="${e.description}" >${e.title}</h4>
				
				<div class="prompt-group-items" data-prefix="${e.prefix}" data-suffix="${e.suffix}">`;for(let t of e.items)a+=`<a 
                class="prompt-group-item ${t.img?"":"btn btn-small btn-outlined"} " 
								title="Hold CMD for random : ${t.description}"
								data-title="${t.title}"
                ${t.prefix?"data-prefix='"+t.prefix+"'":""} 
                ${t.suffix?"data-suffix='"+t.suffix+"'":""} 
                
								data-variants="${t.variants.join(",")}"
								data-type="${t.type}">${t.title}`,t.img&&(a+=`<div class="preview-image"><img src="${v}${t.img}" alt="${t.title}"/></div>`),a+="</a>";a+="</div>",r.querySelector("#prompt-helper-drawer").appendChild(document.createRange().createContextualFragment(a))}}return r},y=async function(){document.querySelector(".image-prompt-form");let o=document.querySelector(".image-prompt-form-header").querySelector("div:first-child>div");o.insertAdjacentHTML("beforeend",h);let n=document.querySelector(".image-prompt-form-wrapper");n.append(w()),n.insertAdjacentHTML("beforeEnd",b),document.querySelector("html").dataset.theme="dark";let e=document.querySelector(".image-prompt-input");o.addEventListener("click",async function(a){if(a.target.id=="prompt-helper-btn"&&document.querySelector("#prompt-helper-drawer").classList.toggle("open"),a.target.id=="gpt3-synonym"){document.querySelector(".btn-options").classList.add("loading");let t=a.target.dataset.selection,s=await u("get-synonym",{value:t},"background");e.value=e.value.replace(e.value.substring(e.selectionStart,e.selectionEnd),s),document.querySelector(".btn-options").classList.remove("loading"),d(e,e.value);let i=e.value.indexOf(s);console.log(i,e.value,s),e.setSelectionRange(i,i+s.length,"forward"),e.focus()}if(a.target.id=="gpt3-autocomplete"){let t=e.value;document.querySelector(".btn-options").classList.add("loading");let s=await u("get-autocomplete",{value:t},"background");document.querySelector(".btn-options").classList.remove("loading");let i=s.map(l=>Array.isArray(l)?l[Math.floor(Math.random()*l.length)]:l);e.value=i.join(" "),d(e,e.value),e.focus()}}),e.addEventListener("keyup",c),e.addEventListener("mousedown",c),e.addEventListener("mousemove",c),document.querySelector("#prompt-helper-drawer").addEventListener("click",function(a){let t=a.target.dataset.suffix||a.target.parentNode.dataset.suffix||"",s=a.target.dataset.prefix||a.target.parentNode.dataset.prefix||"",i=a.metaKey||a.ctrlKey;if(e.selectionStart!=e.selectionEnd&&(e.value=e.value.replace(e.value.substring(e.selectionStart,e.selectionEnd),"")),e.value,a.target.dataset.type=="random"||i){let l=a.target.dataset.variants.split(","),p=l[Math.floor(Math.random()*l.length)];e.value+=`${s}${p}${t}`}if(a.target.dataset.type=="toggle"&&!i){let l=`${s}${a.target.dataset.title}${t}`;e.value.includes(l)?e.value=e.value.replace(l,""):e.value+=l}d(e,e.value),e.focus()})};var x=new MutationObserver(r=>{var e;for(var o of r){if(o.type=="childList"&&o.addedNodes.length>0)for(var n=0;n<o.addedNodes.length;n++){let t=o.addedNodes[n].classList;((t==null?void 0:t.contains("edit-page"))||(t==null?void 0:t.contains("edit-page")))&&((e=document.querySelector("#prompt-helper-drawer"))==null||e.classList.remove("open"))}if(g())return;document.querySelector(".image-prompt-form")!=null&&y()}});const S={childList:!0,subtree:!0};x.observe(document.body,S);function d(r,o){let n=r.value;r.value=o;let e=new Event("input",{target:r,bubbles:!0});e.simulated=!0;let a=r._valueTracker;a&&a.setValue(n),r.dispatchEvent(e)}function c(){let r=document.querySelector(".image-prompt-input"),o=document.querySelector("#gpt3-synonym");r.selectionStart!=r.selectionEnd?(o.classList.add("selection"),o.dataset.selection=r.value.substring(r.selectionStart,r.selectionEnd)):(o.classList.remove("selection"),o.dataset.selection="")}
