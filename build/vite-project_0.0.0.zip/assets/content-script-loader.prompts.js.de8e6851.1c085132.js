(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/prompts.js.de8e6851.js")
    );
  })().catch(console.error);

})();
