(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/inject.js.8390ca5a.js")
    );
  })().catch(console.error);

})();
