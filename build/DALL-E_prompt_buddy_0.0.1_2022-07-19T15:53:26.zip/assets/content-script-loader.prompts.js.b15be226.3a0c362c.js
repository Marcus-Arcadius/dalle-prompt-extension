(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/prompts.js.b15be226.js")
    );
  })().catch(console.error);

})();
