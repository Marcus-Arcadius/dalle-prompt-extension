import{b as g,s as m}from"./index.a132e794.js";import{a as d}from"./themeHandler.a2649445.js";let v=function(){return!!document.querySelector("#prompt-helper-btn")},f=g.exports.runtime.getURL("img/"),h=g.exports.runtime.getURL(""),b=`
<button id="prompt-helper-btn" tabindex="0" class="btn btn-small btn-filled btn-primary" type="button">
	<span class="btn-label-wrap">
		<span class="btn-label-inner">
    Prompt Helper</span> 
	</span>
</button>

<a id="gpt3-synonym" data-selection="" class="btn btn-small btn-filled btn-primary">Synonym with GPT-3

</a>
<a id="gpt3-autocomplete" class="btn btn-small btn-outlined ">Autocomplete with GPT-3</a>

<a href="${h}options.html" target="_blank" class="btn btn-small btn-icon btn-options">
<svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
  <path stroke-linecap="round" stroke-linejoin="round" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
</svg>

<span class="btn-spinner"
      ><div class="spinner">
        <svg
          stroke="currentColor"
          fill="currentColor"
          stroke-width="0"
          viewBox="0 0 1024 1024"
          class="spinner-spin"
          color="currentColor"
          height="1.2em"
          width="1.2em"
          xmlns="http://www.w3.org/2000/svg"
          style="color: currentcolor"
        >
          <path
            d="M988 548c-19.9 0-36-16.1-36-36 0-59.4-11.6-117-34.6-171.3a440.45 440.45 0 0 0-94.3-139.9 437.71 437.71 0 0 0-139.9-94.3C629 83.6 571.4 72 512 72c-19.9 0-36-16.1-36-36s16.1-36 36-36c69.1 0 136.2 13.5 199.3 40.3C772.3 66 827 103 874 150c47 47 83.9 101.8 109.7 162.7 26.7 63.1 40.2 130.2 40.2 199.3.1 19.9-16 36-35.9 36z"
          ></path>
        </svg></div
    ></span>
</a>
`,w=`
<div class="dark-mode-toggle">
  <div class="dark-mode-active"></div>
  <div id="light-mode" class="btn btn-icon">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
      <path fill-rule="evenodd" d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z" clip-rule="evenodd" />
    </svg>
  </div>
  <div id="dark-mode" class="btn btn-icon">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
      <path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z" />
    </svg>
  </div>
</div>
`,y=function(){let r="";if(!window.prompts)r="<div>Something went wrong, no prompts found!</div>";else{r=document.createDocumentFragment();let o=document.createElement("div");o.classList.add("helper-drawer"),o.id="prompt-helper-drawer",r.appendChild(o),r.querySelector("#prompt-helper-drawer").insertAdjacentHTML("beforeEnd",w);for(let i in window.prompts){let e=window.prompts[i],t=`
				<h4 class="prompt-group-title" title="${e.description}">${e.title}</h4>
				
				<div class="prompt-group-items" data-prefix="${e.prefix}" data-suffix="${e.suffix}">`;for(let a of e.items)t+=`<a 
                class="prompt-group-item ${a.img?"":"btn btn-small btn-outlined"} " 
								title="cmd+click to randomize : ${a.description}"
								data-title="${a.title}"
                ${a.prefix?"data-prefix='"+a.prefix+"'":""} 
                ${a.suffix?"data-suffix='"+a.suffix+"'":""} 
                
								data-variants="${a.variants.join(",")}"
								data-type="${a.type}">${a.title}`,a.img&&(t+=`<div class="preview-image"><img src="${f}${a.img}" alt="${a.title}"/></div>`),t+="</a>";t+="</div>",r.querySelector("#prompt-helper-drawer").appendChild(document.createRange().createContextualFragment(t))}}return r},x=async function(){document.querySelector(".image-prompt-form");let o=document.querySelector(".image-prompt-form-header").querySelector("div:first-child>div");o.insertAdjacentHTML("beforeend",b),document.querySelector(".image-prompt-form-wrapper").append(y()),d();let e=document.querySelector(".image-prompt-input");o.addEventListener("click",async function(t){if(t.target.id=="prompt-helper-btn"&&document.querySelector("#prompt-helper-drawer").classList.toggle("open"),t.target.id=="gpt3-synonym"){document.querySelector(".btn-options").classList.add("loading");let a=t.target.dataset.selection,n=await m("get-synonym",{value:a},"background");e.value=e.value.replace(e.value.substring(e.selectionStart,e.selectionEnd),n),document.querySelector(".btn-options").classList.remove("loading"),c(e,e.value);let s=e.value.indexOf(n);console.log(s,e.value,n),e.setSelectionRange(s,s+n.length,"forward"),e.focus()}if(t.target.id=="gpt3-autocomplete"){let a=e.value;document.querySelector(".btn-options").classList.add("loading");let n=await m("get-autocomplete",{value:a},"background");document.querySelector(".btn-options").classList.remove("loading");let s=n.map(l=>Array.isArray(l)?l[Math.floor(Math.random()*l.length)]:l);e.value=s.join(" "),c(e,e.value),e.focus()}}),e.addEventListener("keyup",p),e.addEventListener("mousedown",p),e.addEventListener("mousemove",p),document.querySelector("#prompt-helper-drawer").addEventListener("click",function(t){let a=t.target.dataset.suffix||t.target.parentNode.dataset.suffix||"",n=t.target.dataset.prefix||t.target.parentNode.dataset.prefix||"",s=t.metaKey||t.ctrlKey;if(e.selectionStart!=e.selectionEnd&&(e.value=e.value.replace(e.value.substring(e.selectionStart,e.selectionEnd),"")),e.value,t.target.dataset.type=="random"||s){let l=t.target.dataset.variants.split(","),u=l[Math.floor(Math.random()*l.length)];e.value+=`${n}${u}${a}`}if(t.target.dataset.type=="toggle"&&!s){let l=`${n}${t.target.dataset.title}${a}`;e.value.includes(l)?e.value=e.value.replace(l,""):e.value+=l}t.target.id=="light-mode"&&d("light"),t.target.id=="dark-mode"&&d("dark"),c(e,e.value),e.focus()})};var S=new MutationObserver(r=>{var e;for(var o of r){if(o.type=="childList"&&o.addedNodes.length>0)for(var i=0;i<o.addedNodes.length;i++){let a=o.addedNodes[i].classList;((a==null?void 0:a.contains("edit-page"))||(a==null?void 0:a.contains("edit-page")))&&((e=document.querySelector("#prompt-helper-drawer"))==null||e.classList.remove("open"))}if(v())return;document.querySelector(".image-prompt-form")!=null&&x()}});const $={childList:!0,subtree:!0};S.observe(document.body,$);function c(r,o){let i=r.value;r.value=o;let e=new Event("input",{target:r,bubbles:!0});e.simulated=!0;let t=r._valueTracker;t&&t.setValue(i),r.dispatchEvent(e)}function p(){let r=document.querySelector(".image-prompt-input"),o=document.querySelector("#gpt3-synonym");r.selectionStart!=r.selectionEnd?(o.classList.add("selection"),o.dataset.selection=r.value.substring(r.selectionStart,r.selectionEnd)):(o.classList.remove("selection"),o.dataset.selection="")}
