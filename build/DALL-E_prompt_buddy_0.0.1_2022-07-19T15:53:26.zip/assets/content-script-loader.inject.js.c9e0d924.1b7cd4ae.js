(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/inject.js.c9e0d924.js")
    );
  })().catch(console.error);

})();
